$(document).ready(function() {
  $('#location_languages,#service_languages').select2();
});
